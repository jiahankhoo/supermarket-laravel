<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>订单详情 #<?php echo e($order->id); ?> - Laravel 超市系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <i class="fas fa-store"></i> Laravel 超市系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                                    <i class="fas fa-tachometer-alt"></i> 仪表板
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.products.index')); ?>">
                                    <i class="fas fa-box"></i> 商品管理
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('cart.index')); ?>">
                                    <i class="fas fa-shopping-cart"></i> 购物车
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('orders.index')); ?>">
                                    <i class="fas fa-shopping-bag"></i> 我的订单
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('chat.index')); ?>">
                                <i class="fas fa-comments"></i> <?php echo e(Auth::user()->isAdmin() ? '客户聊天' : '在线客服'); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">
                                <i class="fas fa-sign-in-alt"></i> 登录
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">
                                <i class="fas fa-user-plus"></i> 注册
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?>

                                <?php if(Auth::user()->isAdmin()): ?>
                                    <span class="badge bg-warning">管理员</span>
                                <?php else: ?>
                                    <span class="badge bg-info">用户</span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('home')); ?>">
                                    <i class="fas fa-home"></i> 返回首页
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item">
                                            <i class="fas fa-sign-out-alt"></i> 退出登录
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- 面包屑导航 -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">首页</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('orders.index')); ?>">订单列表</a></li>
                <li class="breadcrumb-item active" aria-current="page">订单 #<?php echo e($order->id); ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- 订单信息 -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-shopping-bag"></i> 订单详情 #<?php echo e($order->id); ?></h4>
                    </div>
                    <div class="card-body">
                        <!-- 订单状态 -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6><i class="fas fa-info-circle"></i> 订单状态</h6>
                                <span class="badge <?php echo e($order->status_badge); ?> fs-6"><?php echo e($order->status_text); ?></span>
                            </div>
                            <div class="col-md-6">
                                <h6><i class="fas fa-calendar"></i> 创建时间</h6>
                                <p class="text-muted"><?php echo e($order->created_at->format('Y-m-d H:i:s')); ?></p>
                            </div>
                        </div>

                        <!-- 收货地址 -->
                        <?php if($order->receiver_name): ?>
                        <div class="row mb-4">
                            <div class="col-12">
                                <h6><i class="fas fa-map-marker-alt"></i> 收货地址</h6>
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p><strong>收货人：</strong><?php echo e($order->receiver_name); ?></p>
                                                <p><strong>联系电话：</strong><?php echo e($order->receiver_phone); ?></p>
                                            </div>
                                            <div class="col-md-6">
                                                <p><strong>城市：</strong><?php echo e($order->city); ?></p>
                                                <p><strong>邮政编码：</strong><?php echo e($order->postal_code); ?></p>
                                            </div>
                                        </div>
                                        <p><strong>详细地址：</strong><?php echo e($order->shipping_address); ?></p>
                                        <?php if($order->notes): ?>
                                            <p><strong>备注：</strong><?php echo e($order->notes); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- 取消申请信息 -->
                        <?php if($order->cancellation_requested_at): ?>
                        <div class="row mb-4">
                            <div class="col-12">
                                <h6><i class="fas fa-exclamation-triangle text-warning"></i> 取消申请信息</h6>
                                <div class="card border-warning">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p><strong>申请时间：</strong><?php echo e($order->cancellation_requested_at->format('Y-m-d H:i:s')); ?></p>
                                                <p><strong>取消原因：</strong></p>
                                                <div class="bg-light p-2 rounded">
                                                    <?php echo e($order->cancellation_reason); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <?php if($order->admin_response): ?>
                                                    <p><strong>商家回复：</strong></p>
                                                    <div class="bg-light p-2 rounded">
                                                        <?php echo e($order->admin_response); ?>

                                                    </div>
                                                    <p class="mt-2">
                                                        <strong>回复时间：</strong><?php echo e($order->admin_responded_at->format('Y-m-d H:i:s')); ?><br>
                                                        <strong>回复人：</strong><?php echo e($order->adminResponder->name ?? '未知'); ?>

                                                    </p>
                                                <?php else: ?>
                                                    <p class="text-muted"><em>等待商家回复...</em></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- 商品列表 -->
                        <h6><i class="fas fa-box"></i> 商品列表</h6>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>商品图片</th>
                                        <th>商品名称</th>
                                        <th>单价</th>
                                        <th>数量</th>
                                        <th>小计</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($item->product->image_url): ?>
                                                    <img src="<?php echo e($item->product->image_url); ?>" alt="<?php echo e($item->product->name); ?>" 
                                                         class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center" 
                                                         style="width: 50px; height: 50px;">
                                                        <i class="fas fa-image"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong><?php echo e($item->product->name); ?></strong>
                                                <?php if($item->product->description): ?>
                                                    <br><small class="text-muted"><?php echo e(Str::limit($item->product->description, 50)); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>¥<?php echo e(number_format($item->price, 2)); ?></td>
                                            <td><?php echo e($item->quantity); ?></td>
                                            <td class="text-success fw-bold">¥<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 订单摘要 -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-receipt"></i> 订单摘要</h5>
                    </div>
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-6">商品数量:</div>
                            <div class="col-6 text-end"><?php echo e($order->orderItems->count()); ?> 件</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">商品总价:</div>
                            <div class="col-6 text-end">¥<?php echo e(number_format($order->total_amount, 2)); ?></div>
                        </div>
                        <hr>
                        <div class="row mb-3">
                            <div class="col-6"><strong>订单总额:</strong></div>
                            <div class="col-6 text-end">
                                <strong class="text-success fs-5">¥<?php echo e(number_format($order->total_amount, 2)); ?></strong>
                            </div>
                        </div>

                        <!-- 管理员操作 -->
                        <?php if(Auth::user()->isAdmin()): ?>
                            <div class="mt-3">
                                <h6><i class="fas fa-cog"></i> 管理员操作</h6>
                                <button type="button" class="btn btn-warning btn-sm w-100" 
                                        data-bs-toggle="modal" data-bs-target="#statusModal">
                                    <i class="fas fa-edit"></i> 更新订单状态
                                </button>
                                
                                <!-- 取消申请回复 -->
                                <?php if($order->status === 'cancellation_requested'): ?>
                                    <button type="button" class="btn btn-info btn-sm w-100 mt-2" 
                                            data-bs-toggle="modal" data-bs-target="#cancellationResponseModal">
                                        <i class="fas fa-reply"></i> 回复取消申请
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <!-- 用户操作 -->
                        <?php if(Auth::user()->isUser() && $order->user_id === Auth::id()): ?>
                            <div class="mt-3">
                                <h6><i class="fas fa-user-cog"></i> 用户操作</h6>
                                <?php if($order->canRequestCancellation()): ?>
                                    <a href="<?php echo e(route('orders.cancellation-form', $order)); ?>" class="btn btn-warning btn-sm w-100">
                                        <i class="fas fa-times-circle"></i> 申请取消订单
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <!-- 返回按钮 -->
                        <div class="mt-3">
                            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-arrow-left"></i> 返回订单列表
                            </a>
                        </div>
                    </div>
                </div>

                <!-- 用户信息 -->
                <div class="card mt-3">
                    <div class="card-header">
                        <h6><i class="fas fa-user"></i> 用户信息</h6>
                    </div>
                    <div class="card-body">
                        <p class="mb-1"><strong>用户名:</strong> <?php echo e($order->user->name); ?></p>
                        <p class="mb-1"><strong>邮箱:</strong> <?php echo e($order->user->email); ?></p>
                        <p class="mb-0"><strong>角色:</strong> 
                            <?php if($order->user->isAdmin()): ?>
                                <span class="badge bg-warning">管理员</span>
                            <?php else: ?>
                                <span class="badge bg-info">用户</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 状态更新模态框 -->
    <?php if(Auth::user()->isAdmin()): ?>
        <div class="modal fade" id="statusModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">更新订单状态</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="<?php echo e(route('orders.update-status', $order)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="status" class="form-label">订单状态</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>待处理</option>
                                    <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>处理中</option>
                                    <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>已完成</option>
                                    <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>已取消</option>
                                    <option value="cancellation_requested" <?php echo e($order->status == 'cancellation_requested' ? 'selected' : ''); ?>>申请取消中</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                            <button type="submit" class="btn btn-primary">更新状态</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- 取消申请回复模态框 -->
        <?php if($order->status === 'cancellation_requested'): ?>
        <div class="modal fade" id="cancellationResponseModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-reply text-info"></i> 回复取消申请
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="<?php echo e(route('orders.respond-cancellation', $order)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <!-- 取消申请详情 -->
                            <div class="alert alert-warning">
                                <h6><i class="fas fa-info-circle"></i> 取消申请详情</h6>
                                <p><strong>申请时间：</strong><?php echo e($order->cancellation_requested_at->format('Y-m-d H:i:s')); ?></p>
                                <p><strong>取消原因：</strong></p>
                                <div class="bg-light p-2 rounded">
                                    <?php echo e($order->cancellation_reason); ?>

                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="admin_response" class="form-label">
                                    <i class="fas fa-comment"></i> 回复内容 <span class="text-danger">*</span>
                                </label>
                                <textarea 
                                    class="form-control <?php $__errorArgs = ['admin_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="admin_response" 
                                    name="admin_response" 
                                    rows="4" 
                                    placeholder="请详细说明您的回复..."
                                    required
                                ><?php echo e(old('admin_response')); ?></textarea>
                                <?php $__errorArgs = ['admin_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="action" class="form-label">
                                    <i class="fas fa-check-circle"></i> 处理决定 <span class="text-danger">*</span>
                                </label>
                                <select class="form-select <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="action" name="action" required>
                                    <option value="">请选择处理决定</option>
                                    <option value="approve" <?php echo e(old('action') == 'approve' ? 'selected' : ''); ?>>
                                        <i class="fas fa-check"></i> 批准取消申请
                                    </option>
                                    <option value="reject" <?php echo e(old('action') == 'reject' ? 'selected' : ''); ?>>
                                        <i class="fas fa-times"></i> 拒绝取消申请
                                    </option>
                                </select>
                                <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="alert alert-info">
                                <h6><i class="fas fa-lightbulb"></i> 处理说明</h6>
                                <ul class="mb-0">
                                    <li><strong>批准取消：</strong>订单将被取消，商品库存将自动恢复</li>
                                    <li><strong>拒绝取消：</strong>订单将继续处理，状态变为"处理中"</li>
                                    <li>您的回复将发送给客户，请确保回复内容清晰明确</li>
                                </ul>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i> 提交回复
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> <?php /**PATH C:\Users\User\OneDrive\Desktop\supermarket-laravel\resources\views/orders/show.blade.php ENDPATH**/ ?>