<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>我的订单 - Laravel 超市系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <i class="fas fa-store"></i> Laravel 超市系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                                    <i class="fas fa-tachometer-alt"></i> 仪表板
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.products.index')); ?>">
                                    <i class="fas fa-box"></i> 商品管理
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('cart.index')); ?>">
                                    <i class="fas fa-shopping-cart"></i> 购物车
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(route('orders.index')); ?>">
                                    <i class="fas fa-shopping-bag"></i> 我的订单
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('chat.index')); ?>">
                                <i class="fas fa-comments"></i> <?php echo e(Auth::user()->isAdmin() ? '客户聊天' : '在线客服'); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">
                                <i class="fas fa-sign-in-alt"></i> 登录
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">
                                <i class="fas fa-user-plus"></i> 注册
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?>

                                <?php if(Auth::user()->isAdmin()): ?>
                                    <span class="badge bg-warning">管理员</span>
                                <?php else: ?>
                                    <span class="badge bg-info">用户</span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('home')); ?>">
                                    <i class="fas fa-home"></i> 返回首页
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item">
                                            <i class="fas fa-sign-out-alt"></i> 退出登录
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- 页面标题 -->
        <div class="row mb-4">
            <div class="col">
                <h2>
                    <?php if(Auth::user()->isAdmin()): ?>
                        <i class="fas fa-shopping-bag"></i> 所有订单
                    <?php else: ?>
                        <i class="fas fa-shopping-bag"></i> 我的订单
                    <?php endif; ?>
                </h2>
                <p class="text-muted">
                    <?php if(Auth::user()->isAdmin()): ?>
                        管理系统中的所有订单
                    <?php else: ?>
                        查看您的订单历史
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <!-- 订单列表 -->
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-list"></i> 订单列表</h5>
            </div>
            <div class="card-body">
                <?php if($orders->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>订单号</th>
                                    <th>用户</th>
                                    <th>收货人</th>
                                    <th>商品数量</th>
                                    <th>总金额</th>
                                    <th>状态</th>
                                    <th>创建时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong>#<?php echo e($order->id); ?></strong>
                                        </td>
                                        <td>
                                            <?php if(Auth::user()->isAdmin()): ?>
                                                <?php echo e($order->user->name); ?>

                                            <?php else: ?>
                                                <?php echo e(Auth::user()->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($order->receiver_name): ?>
                                                <div>
                                                    <strong><?php echo e($order->receiver_name); ?></strong>
                                                    <br><small class="text-muted"><?php echo e($order->city); ?></small>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">未填写</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo e($order->orderItems->count()); ?> 件</span>
                                        </td>
                                        <td>
                                            <span class="text-success fw-bold">¥<?php echo e(number_format($order->total_amount, 2)); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo e($order->status_badge); ?>"><?php echo e($order->status_text); ?></span>
                                            <?php if($order->cancellation_requested_at && !$order->admin_response): ?>
                                                <br><small class="text-warning"><i class="fas fa-clock"></i> 等待回复</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo e($order->created_at->format('Y-m-d H:i')); ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i> 查看
                                                </a>
                                                <?php if(Auth::user()->isAdmin()): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-warning" 
                                                            data-bs-toggle="modal" data-bs-target="#statusModal<?php echo e($order->id); ?>">
                                                        <i class="fas fa-edit"></i> 状态
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">暂无订单</h5>
                        <p class="text-muted">
                            <?php if(Auth::user()->isAdmin()): ?>
                                系统中还没有订单
                            <?php else: ?>
                                您还没有下过订单，去 <a href="<?php echo e(route('home')); ?>">首页</a> 选购商品吧！
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 统计信息 -->
        <?php if($orders->count() > 0): ?>
            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="card bg-primary text-white">
                        <div class="card-body text-center">
                            <h4><?php echo e($orders->count()); ?></h4>
                            <p class="mb-0">总订单数</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white">
                        <div class="card-body text-center">
                            <h4><?php echo e($orders->where('status', 'completed')->count()); ?></h4>
                            <p class="mb-0">已完成</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white">
                        <div class="card-body text-center">
                            <h4><?php echo e($orders->where('status', 'pending')->count()); ?></h4>
                            <p class="mb-0">待处理</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white">
                        <div class="card-body text-center">
                            <h4>¥<?php echo e(number_format($orders->where('status', 'completed')->sum('total_amount'), 2)); ?></h4>
                            <p class="mb-0">总销售额</p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- 状态更新模态框 -->
    <?php if(Auth::user()->isAdmin()): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="statusModal<?php echo e($order->id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">更新订单状态</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <form method="POST" action="<?php echo e(route('orders.update-status', $order)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="status" class="form-label">订单状态</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>待处理</option>
                                        <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>处理中</option>
                                        <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>已完成</option>
                                        <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>已取消</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                                <button type="submit" class="btn btn-primary">更新状态</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> <?php /**PATH C:\Users\User\OneDrive\Desktop\supermarket-laravel\resources\views/orders/index.blade.php ENDPATH**/ ?>